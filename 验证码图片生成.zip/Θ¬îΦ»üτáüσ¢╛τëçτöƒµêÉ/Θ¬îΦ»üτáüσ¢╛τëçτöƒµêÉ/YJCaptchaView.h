//
//  YJCaptchaView.h
//  test
//
//  Created by admin on 16/8/1.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  验证码字体大小
 *
 */
#define kFontSize [UIFont systemFontOfSize:arc4random() % 5 + 15]

@interface YJCaptchaView : UIView

/**
 *  验证码字符串 默认aBcD
 */
@property (nonatomic,strong) NSString *changeString; 

/**
 *  背景颜色 默认为随机色
 */
@property (nonatomic,strong) UIColor *bgColor;

/**
 *  模糊线数量 默认6条
 */
@property (nonatomic,assign) NSInteger vagueLineCount;

/**
 *  模糊线宽度 默认1.0f
 */
@property (nonatomic,assign) CGFloat vagueLineWidth;

/**
 *  点击view之后的回调
 */
@property (nonatomic, copy) void (^clickCaptchaViewBlock)();

@end
