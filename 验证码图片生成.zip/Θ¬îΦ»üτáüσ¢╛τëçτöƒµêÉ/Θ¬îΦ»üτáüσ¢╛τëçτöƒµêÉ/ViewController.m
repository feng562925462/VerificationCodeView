//
//  ViewController.m
//  验证码图片生成
//
//  Created by 冯垚杰 on 16/8/2.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import "ViewController.h"
#import "NSString+YJ_Extension.h"
#import "YJCaptchaView.h"

@interface ViewController ()

@property (nonatomic,strong) YJCaptchaView *CaptchaView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    /**
     YJCaptchaView 最小高度不得低于23，否则会不显示；最佳高度为30
        4位验证码 最小宽度不得小于 45 否则会不显示；最佳宽度为80，
     - returns:
     */
    self.CaptchaView = [[YJCaptchaView alloc] initWithFrame:CGRectMake(0, 0, 80, 30)];
    
    self.CaptchaView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2.f, [UIScreen mainScreen].bounds.size.height / 2.f);
    
    __weak ViewController *weakSelf = self;
    [self.CaptchaView setClickCaptchaViewBlock:^{
        NSLog(@"点击了YJCaptchaView");
        weakSelf.CaptchaView.changeString = [NSString getRandomNumberOfVerificationCodeWithCount:4];
    }];
    
    self.CaptchaView.bgColor = [UIColor grayColor];
    
    [self.view addSubview:self.CaptchaView];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"点击了屏幕");
    self.CaptchaView.changeString = [NSString getRandomNumberOfVerificationCodeWithCount:4];
}

@end
