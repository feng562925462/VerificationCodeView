//
//  ViewController.m
//  验证码图片生成
//
//  Created by 冯垚杰 on 16/8/2.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import "ViewController.h"
#import "NSString+YJ_Extension.h"
#import "YJCaptchaView.h"

@interface ViewController ()

@property (nonatomic,strong) YJCaptchaView *CaptchaView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.CaptchaView = [[YJCaptchaView alloc] initWithFrame:CGRectMake(0, 0, 100, 50)];
    
    self.CaptchaView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2.f, [UIScreen mainScreen].bounds.size.height / 2.f);
    
    __weak ViewController *weakSelf = self;
    [self.CaptchaView setClickCaptchaViewBlock:^{
        NSLog(@"点击了YJCaptchaView");
        weakSelf.CaptchaView.changeString = [NSString getRandomNumberOfVerificationCodeWithCount:arc4random() % 5 + 2];
    }];
    
    [self.view addSubview:self.CaptchaView];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"点击了屏幕");
    self.CaptchaView.changeString = [NSString getRandomNumberOfVerificationCodeWithCount:arc4random() % 5 + 2];
}

@end
