//
//  AppDelegate.h
//  验证码图片生成
//
//  Created by 冯垚杰 on 16/8/2.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

