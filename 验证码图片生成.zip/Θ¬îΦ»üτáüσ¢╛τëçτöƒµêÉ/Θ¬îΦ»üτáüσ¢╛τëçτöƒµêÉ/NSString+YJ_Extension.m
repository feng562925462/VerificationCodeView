//
//  NSString+YJ_Extension.m
//  test
//
//  Created by 冯垚杰 on 16/8/1.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "NSString+YJ_Extension.h"

@implementation NSString (YJ_Extension)

+ (NSString *)getRandomNumberOfVerificationCodeWithCount:(NSInteger)count {

    //<一>从字符数组中随机抽取相应数量的字符，组成验证码字符串
    //数组中存放的是全部可选的字符，可以是字母，也可以是中文
     NSArray *arr = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"a",@"b",@"c",@"d",@"e",@"f",@"g",@"h",@"i",@"j",@"k",@"l",@"m",@"n",@"o",@"p",@"q",@"r",@"s",@"t",@"u",@"v",@"w",@"x",@"y",@"z"];
    
    //如果能确定最大需要的容量，使用initWithCapacity:来设置，好处是当元素个数不超过容量时，添加元素不需要重新分配内存
    NSMutableString *changeString = [[NSMutableString alloc] initWithCapacity:count];

    //随机从数组中选取需要个数的字符，然后拼接为一个字符串
    for(int i = 0; i < count; i++)
    {
        NSInteger index = arc4random() % (arr.count - 1);
        
        [changeString appendString:arr[index]];
    }
    return changeString;
}

@end
