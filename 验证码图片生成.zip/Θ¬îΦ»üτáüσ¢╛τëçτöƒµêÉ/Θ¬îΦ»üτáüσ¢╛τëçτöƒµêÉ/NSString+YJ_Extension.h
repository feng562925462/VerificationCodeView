//
//  NSString+YJ_Extension.h
//  test
//
//  Created by 冯垚杰 on 16/8/1.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (YJ_Extension)

/**
 *  获取随机验证码
 *
 *  @param count 验证的字符数量
 *
 *  @return 随机验证码
 */
+ (NSString *) getRandomNumberOfVerificationCodeWithCount:(NSInteger)count;




@end
