//
//  YJ_NetworkRequest.h
//  封装
//
//  Created by admin on 16/7/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YJ_ConfigurationFile.h"
#import "AFNetworking.h"

typedef NS_ENUM (NSInteger,FNetworkStatus) {
    FNetworkStatusNotReachable = 0, //无网络
    FNetworkStatusUnknown,  //未知网络
    FNetworkStatusReachableViaWWAN, //蜂窝网络
    FNetworkStatusReachableViaWiFi, //WIFI
};

@interface YJ_NetworkRequest : NSObject

YJ_SingletonH(Request)

/**
 * get 请求
 *
 *  @param URLString        域名
 *  @param parameters       参数
 *  @param downloadProgress 进度
 *  @param success          成功与否
 *  @param failure          失败
 */
- (void)GET:(NSString *)URLString
 parameters:(id)parameters
   progress:(void (^)(CGFloat progress))downloadProgress
    success:(void (^)(id responseObject))success
    failure:(void (^)(NSError *error))failure;

/**
 *  post 请求
 *
 *  @param URLString  域名
 *  @param parameters 参数
 *  @param success    成功
 *  @param failure    失败
 */
- (void)POST:(NSString *)URLString
  parameters:(id)parameters
     success:(void (^)(id responseObject))success
     failure:(void (^)(NSError *error))failure;

/**
 *  文件上传
 *
 *  @param URLString      域名
 *  @param parameters     参数
 *  @param data           二进制数据
 *  @param mimeType       上传文件类型   （jpg》》》	image/jpeg）
 *  @param fileName       上传到服务器的文件名  注意一定要加 .jpg或者.png
 *  @param success        成功
 *  @param uploadProgress 进度
 *  @param failure        失败
 *  @param name           服务所对应的字段
 */
- (void)POST:(NSString *)URLString
  parameters:(id)parameters
        data:(NSData *)data
        name:(NSString *)name
    mimeType:(NSString *)mimeType
    fileName:(NSString *)fileName
     success:(void (^)(id responseObject))success
    progress:(void (^)(CGFloat))uploadProgress
     failure:(void (^)(NSError *error))failure;

/**
 *  文件下载
 *
 *  @param URLString        域名
 *  @param parameters       参数
 *  @param bytesRange       断点续传的位置
 *  @param downloadProgress 进度
 *  @param success          成功
 *  @param failure          失败
 */
- (void)POST:(NSString *)URLString
  parameters:(id)parameters
  bytesRange:(NSRange)bytesRange
    progress:(void (^)(CGFloat))downloadProgress
     success:(void (^)(id responseObject))success
     failure:(void (^)(NSError *error))failure;

/**
 *  网络状态判断
 *
 *  @param block 状态
 */
- (void)setReachabilityStatusChangeBlock:(void (^)(FNetworkStatus Status))block;

@end
