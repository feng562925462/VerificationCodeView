//
//  YJ_NetworkRequest.m
//  封装
//
//  Created by admin on 16/7/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "YJ_NetworkRequest.h"

@implementation YJ_NetworkRequest

YJ_SingletonM(Request)

#pragma mark =============== 对象获取 ===============
- (AFHTTPSessionManager *)getManager
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    // 是否是加密请求
    if (SSLRequest) {
        manager.securityPolicy = [YJ_NetworkRequest customSecurityPolicy];
    }
    
    return manager;
}

+ (AFSecurityPolicy *)customSecurityPolicy
{
    //先导入证书，找到证书的路径
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:@"Admin" ofType:@"cer"];
    NSData *certData = [NSData dataWithContentsOfFile:cerPath];
    
    //AFSSLPinningModeCertificate 使用证书验证模式
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    
    //allowInvalidCertificates 是否允许无效证书（也就是自建的证书），默认为NO
    //如果是需要验证自建证书，需要设置为YES
    securityPolicy.allowInvalidCertificates = YES;
    
    //validatesDomainName 是否需要验证域名，默认为YES；
    //假如证书的域名与你请求的域名不一致，需把该项设置为NO；如设成NO的话，即服务器使用其他可信任机构颁发的证书，也可以建立连接，这个非常危险，建议打开。
    //置为NO，主要用于这种情况：客户端请求的是子域名，而证书上的是另外一个域名。因为SSL证书上的域名是独立的，假如证书上注册的域名是www.google.com，那么mail.google.com是无法验证通过的；当然，有钱可以注册通配符的域名*.google.com，但这个还是比较贵的。
    //如置为NO，建议自己添加对应域名的校验逻辑。
    securityPolicy.validatesDomainName = NO;
    NSSet *set = [[NSSet alloc] initWithObjects:certData, nil];
    securityPolicy.pinnedCertificates = set;
    
    return securityPolicy;
}

#pragma mark =============== get请求 ===============
- (void)GET:(NSString *)URLString
 parameters:(id)parameters
   progress:(void (^)(CGFloat))downloadProgress
    success:(void (^)(id))success
    failure:(void (^)(NSError *))failure {
    
    [[self getManager] GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull progress) {
        //        if (downloadProgress) {
        //            downloadProgress(progress.completedUnitCount / progress.totalUnitCount);
        //        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        id obj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        
        // 处理可能遇到的乱码问题
        if (obj ==  nil && [responseObject length]) {
            NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            NSString *string= [[NSString alloc] initWithData:responseObject encoding:enc];
            success([NSJSONSerialization JSONObjectWithData:[string dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil]);
        } else {
            success(obj);
        }
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

#pragma mark =============== post请求 ===============
- (void)POST:(NSString *)URLString
  parameters:(id)parameters
     success:(void (^)(id))success
     failure:(void (^)(NSError *))failure {
    
    [[self getManager] POST:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success([NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil]);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

#pragma mark =============== 文件上传 ===============

- (void)POST:(NSString *)URLString
  parameters:(id)parameters
        data:(NSData *)data
        name:(NSString *)name
    mimeType:(NSString *)mimeType
    fileName:(NSString *)fileName
     success:(void (^)(id))success
    progress:(void (^)(CGFloat))uploadProgress
     failure:(void (^)(NSError *))failure {
    
    [[self getManager] POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [formData appendPartWithFileData:data name:@"dataFile" fileName:fileName mimeType:mimeType];
        
    } progress:^(NSProgress * _Nonnull progress) {
        if (uploadProgress) {
            uploadProgress(1.0 * progress.completedUnitCount / progress.totalUnitCount);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success([NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil]);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
}
#pragma mark =============== 文件下载 ===============
- (void)POST:(NSString *)URLString
  parameters:(id)parameters
  bytesRange:(NSRange)bytesRange
    progress:(void (^)(CGFloat))downloadProgress
     success:(void (^)(id))success
     failure:(void (^)(NSError *))failure {
    
    NSMutableURLRequest *downloadRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLString]];
    [downloadRequest setValue:@"Range" forHTTPHeaderField:[NSString stringWithFormat:@"bytes=%lu-%@", bytesRange.location, 0 == bytesRange.length ? @"" : [NSString stringWithFormat:@"%lu", (bytesRange.location + bytesRange.length)]]];
    
    [[self getManager] downloadTaskWithRequest:downloadRequest progress:^(NSProgress * _Nonnull progress) {
        if (downloadProgress) {
            downloadProgress(progress.completedUnitCount / progress.totalUnitCount);
        }
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        // 默认下载地址
        NSLog(@"targetPath = %@",targetPath);
        
        NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        return [NSURL URLWithString:filePath];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        if (!error) {
            success(filePath);
        } else {
            failure(error);
        }
    }];
}
#pragma mark =============== 网络状态判断 ===============
- (void)setReachabilityStatusChangeBlock:(void (^)(FNetworkStatus Status))block
{
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        // 当网络状态改变时调用
        
        switch (status) {
                
            case AFNetworkReachabilityStatusUnknown:
                block(FNetworkStatusUnknown);
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
                block(FNetworkStatusNotReachable);
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                block(FNetworkStatusReachableViaWWAN);
                break;
                
            case AFNetworkReachabilityStatusReachableViaWiFi:
                block(FNetworkStatusReachableViaWiFi);
                break;
        }
    }];
    
    //开始监控
    [manager startMonitoring];
}


@end
