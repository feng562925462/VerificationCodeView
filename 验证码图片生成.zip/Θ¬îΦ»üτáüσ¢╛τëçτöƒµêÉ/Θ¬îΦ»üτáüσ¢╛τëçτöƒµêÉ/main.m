//
//  main.m
//  验证码图片生成
//
//  Created by 冯垚杰 on 16/8/2.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
