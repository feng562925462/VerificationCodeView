//
//  YJCaptchaView.m
//  test
//
//  Created by admin on 16/8/1.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "YJCaptchaView.h"
/**
 *  默认线条数
 */
#define kLineCount 6
/**
 *  默认线宽度
 */
#define kLineWidth 1.0

#define kRandomColor  [UIColor colorWithRed:arc4random() % 256 / 256.0 green:arc4random() % 256 / 256.0 blue:arc4random() % 256 / 256.0 alpha:1.0];

@implementation YJCaptchaView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        self.layer.cornerRadius = 5.0; //设置layer圆角半径
        self.layer.masksToBounds = YES; //隐藏边界
        self.backgroundColor = kRandomColor;
    }
    
    return self;
}

- (void)setChangeString:(NSString *)changeString {
    _changeString = changeString;
    
    [self setNeedsDisplay];
}

- (void)setBgColor:(UIColor *)bgColor {
    _bgColor = bgColor;
    
    self.backgroundColor = bgColor;
    [self setNeedsDisplay];
}

- (void)setVagueLineCount:(NSInteger)vagueLineCount {
    _vagueLineCount = vagueLineCount;
    [self setNeedsDisplay];
}

- (void)setVagueLineWidth:(CGFloat)vagueLineWidth {
    _vagueLineWidth = vagueLineWidth;
    [self setNeedsDisplay];
}

#pragma mark 绘制界面（1.UIView初始化后自动调用； 2.调用setNeedsDisplay方法时会自动调用）
- (void)drawRect:(CGRect)rect {
    // 重写父类方法，首先要调用父类的方法
    [super drawRect:rect];
    
    //获得要显示验证码字符串，根据长度，计算每个字符显示的大概位置
//    NSString *text = @"asdf"; //[NSString stringWithFormat:@"%@",self.changeString];
    if (self.changeString.length == 0 || self.changeString == nil) {
        self.changeString = @"aBcD";
    }
    
    CGSize cSize = [@"S" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20]}];
    int width = rect.size.width / self.changeString.length - cSize.width;
    int height = rect.size.height - cSize.height;
    CGPoint point;
    
    //依次绘制每一个字符,可以设置显示的每个字符的字体大小、颜色、样式等
    float pX, pY;
    for (int i = 0; i < self.changeString.length; i++)
    {
        pX = arc4random() % width + rect.size.width / self.changeString.length * i;
        pY = arc4random() % height;
        point = CGPointMake(pX, pY);
        unichar c = [self.changeString characterAtIndex:i];
        NSString *textC = [NSString stringWithFormat:@"%C", c];
        
        // 设置每个字符的字体大小
        [textC drawAtPoint:point withAttributes:@{NSFontAttributeName:kFontSize}];
    }
    
    //调用drawRect：之前，系统会向栈中压入一个CGContextRef，调用UIGraphicsGetCurrentContext()会取栈顶的CGContextRef
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGFloat w = self.vagueLineWidth > 0 ? self.vagueLineWidth : kLineWidth;
    //设置画线宽度
    CGContextSetLineWidth(context, w);
    
    NSInteger count = self.vagueLineCount ? self.vagueLineCount : kLineCount;
    
    //绘制干扰的彩色直线
    for(int i = 0; i < count; i++)
    {
        //设置线的随机颜色
        UIColor *color = kRandomColor;
        CGContextSetStrokeColorWithColor(context, [color CGColor]);
        //设置线的起点
        pX = arc4random() % (int)rect.size.width;
        pY = arc4random() % (int)rect.size.height;
        CGContextMoveToPoint(context, pX, pY);
        //设置线终点
        pX = arc4random() % (int)rect.size.width;
        pY = arc4random() % (int)rect.size.height;
        CGContextAddLineToPoint(context, pX, pY);
        //画线
        CGContextStrokePath(context);
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.clickCaptchaViewBlock) {
        self.clickCaptchaViewBlock();
    }
}

@end
